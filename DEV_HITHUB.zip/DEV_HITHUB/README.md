# Dev Prakash Jha — Academic Website

A single-page academic site (Home, About, Research, Publications, Projects, CV, Workshops, Contact) built from the CV, with a dark editorial theme, mobile nav, tabbed publications/CV sections, and a downloadable CV.

## Files
- `index.html` — the whole site (HTML/CSS/JS in one file)
- `Dev_Prakash_Jha_CV.pdf` — CV, linked from the "Download CV" buttons
- `images/profile.jpg` — profile photo (used in the About section)

## Publish it on GitHub Pages (free)

1. **Create the repo.** On GitHub, click **New repository**.
   - For a *user site* (URL like `https://<username>.github.io`), name it exactly `<username>.github.io`.
   - For a *project site* (URL like `https://<username>.github.io/dev-prakash-jha`), name it anything, e.g. `dev-prakash-jha`.
2. **Upload the files.** Easiest way with no git experience: on the repo page, click **Add file → Upload files**, drag in `index.html`, `Dev_Prakash_Jha_CV.pdf`, and the `images` folder (keep the folder structure), then **Commit changes**.
   - Or with git installed locally:
     ```bash
     git init
     git add .
     git commit -m "Initial site"
     git branch -M main
     git remote add origin https://github.com/<username>/<repo-name>.git
     git push -u origin main
     ```
3. **Turn on Pages.** In the repo: **Settings → Pages → Build and deployment → Source: Deploy from a branch → Branch: main / (root) → Save.**
4. **Wait ~1 minute**, then visit the URL GitHub shows on that same Pages settings page.

## Updating later
Add new publications, awards, or projects by editing the relevant `<div class="pub">`, `<div class="achv-card">`, or `<div class="proj">` block in `index.html`, then re-upload/commit. No build step — it's static HTML.
